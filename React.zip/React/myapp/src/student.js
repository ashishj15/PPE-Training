// import React from 'react';

// class Student extends React.Component{
//     constructor(){
//         super();
//         this.state={name:"Ashish"};
//     }
//     render(){
//         return <h1>I am {this.state.name} 
//         <Personal/>
//         <Medical/></h1>
//     }

// }

// class Personal extends React.Component{
//     render(){
//         return <h1>I dont share my personal details</h1>
//     }
// }
// class Medical extends React.Component{
//     render(){
//         return <h1>I am fit and fine</h1>
//     }
// }

// export default Student;
// return (  
//     <div>  
//           <ReactTable  
//               data={data}  
//               columns={columns}  
//               defaultPageSize = {2}  
//               pageSizeOptions = {[2,4, 6]}  
//           />  
//       </div>      
// )